#Ex030 - Par ou Impar
num1 = int(input('Digite um número maior que 0: \n'))
if num1 %2 == 0:
    print('Muito Bem, esse número é par')
else:
    print('Beleza, esse número é impar')
#================================================
#Ex031 - Viagem
km = int(input('De Quantos km será a viagem? \n'))
if km == 200:
    print('O preço da viagem será R${}'.format(km*0.50))
else:
    print('O preço da viagem será R${}'.format(km*0.45))