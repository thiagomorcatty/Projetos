#CAIXA ELETRÔNICO - MINHA VERSÃO
print('==='*10)
print(' BANCO PYTHON')
print('==='*10)
ced50 = ced20 = ced10 = ced5 = ced1 = 0
valor = float(input('Que valor deseja sacar? R$ '))
if valor / 100 >= 1:
    ced100 = int(valor // 100)
    print(f'Total de {ced100} cédulas de R$100,00.')
valor1 = valor - (ced100*100)
if valor1 >= 50:
    ced50 = 1
    print(f'Total de {ced50} cédulas de R$50,00.')
valor2 = valor1 - (ced50 * 50)
if valor2 >= 20:
    if valor2 >= 40:
        ced20 = 2
    else:
        ced20 = 1
    print(f'Total de {ced20} cédulas de R$20,00.')
valor3 = valor2 -(ced20*20)
if valor3 >= 10:
    ced10 = 1
    print(f'Total de {ced10} cédulas de R$10,00.')
valor4 = valor3 - (ced10*10)
if valor4 >= 5:
    ced5 = 1
    print(f'Total de {ced5} cédulas de R$5,00.')
valor5 = valor4 - (ced5*5)
if valor5 != 0:
    ced1 = int(valor5)
    print(f'Total de {ced1} cédulas de R$1,00.')
print('==='*10)
print('Volte sempre, Obrigado!!')