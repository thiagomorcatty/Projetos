tab = 0
while True:
    tab = int(input('\033[4;30mDigite um número para saber sua tabuada:\033[m '))
    if tab >= -2:
            for f in range(1,11):
                print(f'{tab} x {f:2} = {tab*f}')
    else:
        break
print('\033[0;34m===+===\033[m'*20)
print('Obrigado por usar o programa da tabuada!!!')
print('\033[0;34m===+===\033[m'*20)
