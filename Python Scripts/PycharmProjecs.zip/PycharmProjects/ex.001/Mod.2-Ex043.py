print('\033[1;36;40m ==+== CALCULO DE IMC ==+== \033[m')
alt = float(input('Digite sua altura: \n'))
peso = float(input('Digite sua peso: \n'))
imc = (peso / (alt*alt))
print('Seu IMC é {}'.format(imc))
if imc <= 18.5:
    print('Está abaixo do peso!')
elif imc > 18.5 and imc <= 25:
    print('Está com o peso ideal')
elif imc > 25 and imc <= 30:
    print('Está em sobrepeso')
elif imc > 30 and imc <= 40:
    print('Está com obesidade')
else:
    print('Está em obesidade mórbida')
