nome = input('Digite seu nome completo \n')
cidade = input('Digite a cidade onde nasceu \n')
texto = input('Escreva um texto\n')
print('=='*20)
#Ex024
print('O nome da cidade tem nome de Santo?')
lista1 = cidade.upper().split()
print('SANTO' in lista1[0])
print('=='*20)
#Ex025
print('\n Você tem Silva no nome?')
print('Silva' in nome)
print('=='*20)
#Ex026
print('Temos {} letras A maiúscula no texto'.format(texto.count('A')))
print('Temos {} letras A totais no texto'.format(texto.upper().count('A')))
print('A primeira letra A aparece no caractere {}'.format(texto.find('A')))
print('A primeira letra A aparece no caractere {} '.format(texto.rfind('A')))
print('=='*20)
#Ex027
lista2 = nome.split()
name1 = lista2[0]
name2 = lista2[len(lista2)-1]
print('Olá {} {}'.format(name1, name2))
print(lista2)
