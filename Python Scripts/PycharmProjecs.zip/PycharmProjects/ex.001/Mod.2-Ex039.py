from time import sleep
from datetime import date
print('\033[1;36;40m ==+== SERVIÇO MILITAR ==+== \033[m')
nasc = int(input('Digite seu ano de nascimento: \n'))
print('PROCESSANDO \n')
sleep(2)
idade = (date.today().year)- nasc
print('Você tem {} anos.'.format(idade))
if idade < 18:
    print('Ainda não tem idade para o alistamento, faltam ainda {} anos.'.format(18-idade))
elif idade == 18:
    print('Parabéns!! Está na idade correta para se alistar!!!'.format(idade))
else:
    print('Já passou a idade para o alistamento, está {} anos atrasado.'.format(idade-18))