#Ex019
from random import choice
from random import shuffle
a1 = str(input('Insira o no nome do primeiro: '))
a2 = str(input('Insira o no nome do segundo : '))
a3 = str(input('Insira o no nome do terceiro: '))
a4 = str(input('Insira o no nome do quarto : '))
print('Dentre as pessoas: {},{},{} e {}'.format(a1, a2, a3, a4))
lista = [a1, a2, a3, a4]
print('\n O mais bonito de todos será {}.Parabéns!!! \n'.format(choice(lista)))
#Ex020
print('A ordem sorteada para estes nomes será:')
shuffle(lista)
print(lista)
