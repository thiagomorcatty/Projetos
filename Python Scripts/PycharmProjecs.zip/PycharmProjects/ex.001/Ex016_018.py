#Ex016 - Separar inteiro
#Ex017 - Hipotenusa
#Ex018 - Trigonometria


import math
#Ex016
num1 = float(input('Digite um número real: \n'))
print('A parte inteira dele é a {}.'.format(math.trunc(num1)))
#Ex017
cop = int(input('Insira o cateto oposto: \n'))
cad = int(input('Insira o cateto adjacente: \n'))
print('Com os catetos {} e {}, a hipotenusa {:.2f}.'.format(cop, cad, (math.sqrt((math.pow(cop,2)) + (math.pow(cad,2))))))
#Ex018
ang = int(input('Insira um ângulo: \n'))
print('O angulo escolhido foi o {}, \n seu Seno será {:.3f}, \n seu Cosseno será {:.3f} \n e sua Tangente será {:.3f}.'.format(ang, math.sin(ang), math.cos(ang), math.tan(ang)))