somaidade = 0
mediaidade = 0
maioridadehomem = 0
nomehomemvelho = ''
totmulher20 = 0
for p in range(1,5):
    print('----- {}ª Pessoa -----'.format(p))
    nome = input('Nome: ').strip()
    idade = int(input('Idade: '))
    sexo = input('Sexo [M/F]: ').strip()
    somaidade += idade
    if p == 1 and sexo in 'Mm':
        maioridadehomem = idade
        nomehomemvelho = nome
    if sexo in 'Mm' and idade > maioridadehomem:
        maioridadehomem = idade
        nomehomemvelho = nome
    if sexo in 'Ff' and idade < 20:
        totmulher20 += 1

mediaidade = somaidade/4
print('A media idade do grupo é de {} anos'.format(mediaidade))
print('O homem mais velho é o {} e tem {} anos'.format(nomehomemvelho,maioridadehomem ))
print('Ao todo são {} mulheres com menos de 20'.format(totmulher20))
