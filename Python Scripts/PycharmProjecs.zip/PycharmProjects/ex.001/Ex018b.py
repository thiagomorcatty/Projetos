# Ex017 - Calculo de hipotenusa
from math import radians, sin, cos, tan
ang = float(input('Insira um ângulo: \n'))
print('O angulo escolhido foi o {}º, \n seu Seno será {:.3f}, \n seu Cosseno será {:.3f} \n e sua Tangente será {:.3f}.'.format(ang, sin(radians(ang)), cos(radians(ang)), tan(radians(ang))))
