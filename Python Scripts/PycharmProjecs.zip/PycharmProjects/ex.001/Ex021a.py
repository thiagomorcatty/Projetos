from playsound import playsound
playsound('Maroon5-Memories.mp3')
