from time import sleep
import emoji
fogo = int(input('Quantos segundos quer contar até os fogos? \n'))
for cont in range(fogo, 0, -1):
    print(cont)
    sleep(1)
print('FOGOSSSSSS!!!! {} e {}'.format(emoji.emojize(':fire:'), emoji.emojize(':collision:')))