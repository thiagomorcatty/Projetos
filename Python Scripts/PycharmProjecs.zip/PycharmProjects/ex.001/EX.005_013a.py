#Ex005 - Sucessor Antecessor,
#Ex006 - Dobro, triplo e raiz
#Ex007 - Media
#Ex008 - Transformação de medidas
#Ex009 - Tabuada
#Ex010 - Cambio
#Ex011 - Area e litros
#Ex012 - Desconto
#Ex013 - Aumento

num1 = int(input('Olá, digite um número: \n '))
print('O número escolhido foi o {}, o seu antecessor é {} e o seu sucessor é {}'.format(num1, num1-1, num1+1))
print('O dobro deste número é {}, o triplo é {} e a raiz é {:.2f}'.format(num1*2, num1*3, num1**(1/2)))
num2 = int(input('Digite a outra nota do aluno \n'))
media = (num1+num2)/2
print('A média entre as duas notas {} e {}, será {}'.format(num1, num2, media))
print('A medida do segundo número em metros é {}, em centímetros é {:.0f} e em milímetros é {:.0f}.'.format(num2, num2*100, num2*1000))
print('A tabuada do segundo número {} será: \n {} x 1 = {}  \n {} x 2 = {} \n {} x 3 = {}  '
      '\n {} x 4 = {} \n {} x 5 = {}  \n {} x 6 = {} \n {} x 7 = {}  \n {} x 8 = {} \n {} x 9 = {} \n'.format(num2, num2, num2, num2, num2*2, num2, num2*3,
                                                                                                              num2, num2*4, num2, num2*5, num2, num2*6,
                                                                                                            num2, num2*7, num2, num2*8, num2, num2*9))

num3 = float(input('Digite a taxa de cambio em reais para $1,00 dollar: \n'))
print('Os valores em dólares, para os números citados {:.2f} e {:.2f}, serão ${:.2f} e ${:.2f} dólares. '.format(num1, num2, num1/num3, num2/num3))
print('Considerando o número digitado {} como largura e o segundo número {} como altura teremos uma área de {}m2. Como cada 2 m2 gasta-se 1l litro, precisaremos de {} de tinta.'.format(num1, num2, num1*num2, num1*num2/2))
print('O cambio escolhido foi de R${:.2f} para cada dollar, mas se tivermos um desconto de 5%, vai ficar R${:.2f} para cada dollar'.format(num3, num3-(num3*0.05)))
print('Se cambio inicial de R${:.2f}, tiver aumento de 15% por variação cambial, teremos o câmbio R${:.2f} por dollar.'.format(num3, num3+(num3*0.15)))
