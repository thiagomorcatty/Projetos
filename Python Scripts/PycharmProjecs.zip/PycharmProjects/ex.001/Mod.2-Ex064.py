num = cont = soma = 0
while num != 999:
    num = int(input('Digite um número [999 termina o programa]: '))
    cont += 1
    soma = soma + num
print(' Você digitou {} números e a soma deles é {}'.format(cont-1, soma-999))