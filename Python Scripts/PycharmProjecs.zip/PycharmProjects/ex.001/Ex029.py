veloc = int(input('Qual a velocidade do carro? (Em km/h) \n'))
multa = (veloc-80)*7
if veloc <= 80:
    print('Parabéns, pode andar à vontade!!!')
else:
    print('Ihhhh tomou multa, vai ter de pagar R${}'.format(multa))
