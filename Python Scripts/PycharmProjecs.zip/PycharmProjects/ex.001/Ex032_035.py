#032 - ano Bissexto
from datetime import date
ano = int(input('Digite o ano que quer saber se é bissexto: \n'))
if ano % 4 == 0 and ano %100 != 0 or ano %400 == 0:
    print('Muito Bem, {} é bissexto!!'.format(ano))
else:
    print('Olha, o ano {} não é bissexto'.format(ano))
print(date.today().year)
#==================
#033 - Maior e Menor
num1 = int(input('Digite um número \n'))
num2 = int(input('Digite outro número \n'))
num3 = int(input('Digite o terceiro número \n'))
if num1 >= num2 and num2 >= num3:
    print(1, 2, 3)
if num1 >= num3 and num2 >= num3:
    print(1, 3, 2)
if num2 >= num3 and num1 >= num3:
    print(2, 1, 3)
if num2 >= num3 and num1 <= num3:
    print(2, 3, 1)
if num3 >= num1 and num1 >= num2:
    print(3, 1, 2)
else:
    print(3, 2, 1)
#==================
#034 - Aumentos mutiplos
sal = float(input('Digite seu salário bruto: \n'))
if sal > 1250:
    print('O salario de R${:.2f} vai aumentar para R${:.2f}'.format(sal, sal+(sal*0.1)) )
else:
    print('O salario de R${:.2f} vai aumentar para R${:.2f}'.format(sal, sal+(sal*0.15)) )
#======================0
#035 - Formar triângulo
ret1 = float(input('Digite o valor do primeiro segmento de reta: \n'))
ret2 = float(input('Digite o valor do segunda segmento de reta: \n'))
ret3 = float(input('Digite o valor do terceira segmento de reta: \n'))
if ret1 < ret2 + ret3 and ret2 < ret1 + ret3 and ret3 < ret1 + ret2:
    print('Ele forma um triângulo')
else: print('Não forma triângulo')