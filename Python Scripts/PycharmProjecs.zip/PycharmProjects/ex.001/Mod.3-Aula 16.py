#Tuplas
#Listas
#Dicionários
lanche = 'Hamburguer','Suco', 'Pizza', 'Pudim','Batata'
#Tuplas são imutáveis
print(lanche)
print(lanche[2])
print(lanche[1])
print(lanche[-1])
print(lanche[1:3])
print(lanche[2:])
print(lanche[:2])
print(lanche[-2:])
print(lanche[:-3])
print('==='*20)
for comida in lanche:
    print(f'Eu vou comer {comida}')
print('Comi muito!!!')
print('==='*20)
print(len(lanche))
for cont in range(0, len(lanche)):
    print(f'Eu vou comer {lanche[cont]}')
    print(f'Eu vou comer {lanche[cont]} na posição {cont}')
print('Comi muito!!!')
print('==='*20)
for pos, comida in enumerate(lanche):
    print(f'Eu vou comer {comida} na posição {pos}')
print('==='*20)
print(lanche)
print(sorted(lanche))
print('==='*20)
a = 2, 5, 4
b = 5, 8, 1, 2
print(a)
print(b)
c = a + b
d = b + a
print(c)
print(d)
print(len(c))
print(c.count(5))
print(c.count(9))
print(d.index(8))
print(d.index(2))
print(d.index(5))
print(d.index(5, 1))
print('==='*20)
pessoa = 'Gustavo', 39, 'M', 99.88
print(pessoa)
print('==='*20)