#Ex060 - Fatorial
from math import factorial
n = int(input('Digite um numero para calcular o fatorial: '))
print('O Fatorial de {} é {}'.format(n, factorial(n)))
print('\033[0;32m ===x===\033[m'*20)
n2 = int(input('Digite um numero para calcular o fatorial: '))
c2 = n2
f2 = 1
print('Calculando {}! = '.format(n2), end='')
while c2 > 0:
    print('{}'.format(c2), end='')
    print(' x ' if c2>1 else ' = ', end='')
    f2 *= c2
    c2 -= 1
print('{}'.format(f2))
print('\033[0;32m ===x===\033[m'*20)
print('\033[0;32m ===x===\033[m'*20)
#Ex061 - PA 2.0
print('Gerador de PA 2.0')
primeiro = int(input('Digite o primeiro termo: '))
razão = int(input('Digite a razão da PA: '))
termo = primeiro
cont = 1
while cont <= 10:
    print('{} -> '.format(termo), end='')
    termo += razão
    cont += 1
print('Fim')
print('\033[0;32m ===x===\033[m'*20)
print('\033[0;32m ===x===\033[m'*20)
#Ex062 - PA 3.0


