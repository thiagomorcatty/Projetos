#Ex047 - Numeros pares entre 1 e 50
print('\033[4;30mEstes são os números pares que temos entre 1 e 50\033[m')
print(list(range(2, 51, 2)))
for n in range(2, 51, 2):
    print(n, end=' ')
print('-')
print('\033[0;34m===+===\033[m'*20)
#Ex048 - Soma numeros impares multiplos de 3 entre 1 e 500
print('\033[4;30mA soma dos números ímpares multiplos de 3 entre 1 e 500 \033[m')
soma = 0
cont = 0
for c in range(1, 501, 2):
    if c % 3 == 0:
        soma = soma + c
        cont += 1
print('A soma {} números, é {}.'.format(cont, soma))
print('\033[0;34m===+===\033[m'*20)
#Ex049 - Tabuada 2.0
tab = int(input('\033[4;30mDigite um número para saber sua tabuada:\033[m \n '))
for f in range(1, 11):
    print('{} x {:2} = {}'.format(tab, f, tab*f))
print('\033[0;34m===+===\033[m'*20)
#Ex050 - Soma apenas dos pares
print('\033[4;30mA soma apenas dos pares \033[m')
soma2 = 0
num1 = int(input(' Insira um número: '))
num2 = int(input(' Insira outro número: '))
num3 = int(input(' Insira outro número: '))
num4 = int(input(' Insira outro número: '))
num5 = int(input(' Insira outro número: '))
num6 = int(input(' Insira o último número: '))
if num1 %2 == 0:
    soma2 = soma2 + num1
if num2 %2 == 0:
    soma2 = soma2 + num2
if num3 %2 == 0:
    soma2 = soma2 + num3
if num4 %2 == 0:
    soma2 = soma2 + num4
if num5 %2 == 0:
    soma2 = soma2 + num5
if num6 %2 == 0:
    soma2 = soma2 + num6
print('A soma dos números pares será {}.'.format(soma2))
soma3 = 0
cont2 = 0
for c1 in range(1,7):
    num7 = int(input('Digite o {} valor: '.format(c1)))
    if num7 % 2 == 0:
        soma3 += num7
        cont2 += 1
print('Você informou {} valores pares e a soma foi  {}'.format(cont2, soma3))
print('\033[0;34m===+===\033[m'*20)
#Ex051 - 10 termos de uma PA
print('\033[4;30m 10 primeiros termos de uma PA \033[m')
term1 = int(input('Digite o primeiro termo: '))
razao = int(input('Digite a razão da PA: '))
decimo = term1 + (10 - 1)*razao
for c2 in range(term1, decimo+1, razao):
    print('{} '.format(c2), end=' ')
print('-')
print('\033[0;34m===+===\033[m'*20)
#Ex052 - Números primos
print('\033[4;30m Números Primos\033[m')
primo = (int(input('Digite um número: ')))
cont3 = 0
for c4 in range(1, primo+1, 1):
    if primo % c4 == 0:
        print(c4, end=' ')
        cont3 += 1
print('')
if cont3 != 2:
    print('O número {} é divisivel {} vezes'.format(primo, cont3))
    print('\033[1;31mPor isso ele NÃO é primo!!!\033[m')
else:
    print('O número {} é divisivel por 1 e ele mesmo!'.format(primo))
    print('\033[1;32mPor isso ele É PRIMO!!!\033[m ')
print('\033[0;34m===+===\033[m'*20)
