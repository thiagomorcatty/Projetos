nome = input('Qual é o seu nome? \n')
if nome == 'Thiago':
    print ('Que ótimo nome, {}'.format(nome))
else: print('Olá, {}.'.format(nome))
#===========
n1 = float(input('Digite um número \n'))
n2 = float(input('Digite outro número \n'))
media = ((n1+n2)/2)
print('Sua média foi: {:.1f}'.format(media))
if media >=10:
    print('Sua média é maior que 10')
else:
    print('Sua média é menor que 10')
#===============


