print('---'*10)
print(' LOJA SUPER BARATÃO')
print('---'*10)
totalcompra = produto100 = preçobarato = cont = 0
produtobarato = ''
while True:
    produto = str(input('Nome do Produto: ')).strip()
    preço = float(input('Preço: '))
    fim = str(input('Pretende adicionar mais produtos? [S/N]: ')).upper().strip()
    print('==+=='*10)
    cont += 1
    if cont == 1: #or preço < preçobarato:
        preçobarato = preço
        produtobarato = produto
    else:
        if preço < preçobarato: #para eliminar este if e simplificar.
            preçobarato = preço
            produtobarato = produto
    totalcompra += preço
    if preço >= 100:
        produto100 += 1
    if fim == 'N':
        break

print(f'O Total da compra foi R${totalcompra:.2f} com {cont} itens')
print(f'Temos {produto100} produtos que custou mais de R$100,00')
print(f'O produto mais barato comprado foi {produtobarato} que custou R${preçobarato:.2f}.')