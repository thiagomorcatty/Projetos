cont = 1
while cont <= 10:
    print(cont, '-> ', end='')
    cont += 1
print('FIM')
print('\033[0;34m~\033[m'*60)
n = s = 0
while n != 999 :
    n = int(input('Digite um número: '))
    s += n
s -= 999
print('A soma vale {}'.format(s))
print('\033[0;34m~\033[m'*60)
n1 = s1 = 0
while True:
    n1 = int(input('Digite um número: '))
    if n1 == 999:
        break
    s1 += n1
print('A soma vale {}'.format(s1))
print(f'A soma vale {s1}')
print('\033[0;34m~\033[m'*60)
nome = 'Jose'
idade = 33
salário = 1000
print('O %s tem %d anos e ganha o salário de R$ %d' % (nome, idade, salário)) #Python 2
print('O {} tem {} anos e ganha o salário de R${:.2f}'.format(nome,idade, salário)) #Python 3
print(f'O {nome} tem {idade} anos e ganha o salário de R${salário:.2f}') #Python 3.6+