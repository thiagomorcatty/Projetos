num1 = float(input('Digite um número: '))
num2 = float(input('Digite o segundo número: '))
print('Escolha o que quer faça com seus números:')
escol = 0
while escol != 5:
    escol = int(input('[1] Somar \n[2] Multiplicar \n[3] Definir o Maior \n[4]Inserir novos números \n[5]Sair do Programa \nEscolha o que quer fazer: '))
    print('\033[0;33m==+==\033[m' * 14)
    if escol == 1:
        print('Escolheu a soma: {} + {} = {}'.format(num1, num2, num1+num2))
        print('\033[0;33m==+==\033[m' * 14)
    elif escol == 2:
        print('Escolheu a multiplicação: {} x {} = {}.'.format(num1, num2, num1*num2))
        print('\033[0;33m==+==\033[m' * 14)
    elif escol == 3:
        if num1 > num2:
            print('O número {} é maior que o número {}'.format(num1, num2))
            print('\033[0;33m==+==\033[m' * 14)
        else:
            print('O número {} é maior que o número {}'.format(num2, num1))
            print('\033[0;33m==+==\033[m' * 14)
    elif escol == 4:
        print('Informe os valores novamente:')
        num1 = float(input('Digite um número: '))
        num2 = float(input('Digite o segundo número: '))
print('Obrigado por usar o programa!!!')
print('\033[0;33m==+==\033[m'*14)