print('=' * 20)
nome = input('Qual é o seu nome? ')
print('Prazer, {:^20}!'.format(nome))
print('Prazer, {:>20}!'.format(nome))
print('Prazer, {:<20}!'.format(nome))
print('Prazer, {:=^20}!'.format(nome))
print('Prazer, {:=<20}!'.format(nome))
print('Prazer, {:=>20}!'.format(nome))

num1 = int(input('Digite um valor: '))
num2 = int(input('Digite outro valor: '))
print('Os números escolhidos foram {} e {}, \n a soma destes números será {}, \n a subtração será {}, \n a multiplicação será {}, \n a divisão será {}, \n a potencia será {}, \n a divisão inteira será {} \n e o resto será {}'.format(num1, num2, num1+num2, num1-num2, num1*num2, num1/num2, num1**num2, num1//num2, num1%num2))

