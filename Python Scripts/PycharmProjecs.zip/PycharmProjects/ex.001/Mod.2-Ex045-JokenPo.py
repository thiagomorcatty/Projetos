from time import sleep
from random import choice
print('\033[0;33m==+==\033[m'*14)
print('_____________________________\033[0;36mJO \033[0;32mKEN \033[0;31mPO \033[m _____________________________')
print('\033[0;33m==+==\033[m'*14)
jogada = int(input('Suas opções de jogada são: \n [ 1 ] PEDRA \n [ 2 ] PAPEL \n [ 3 ] TESOURA \n Que número você escolhe: '))
lista1 = [1, 2, 3]
pc1 = choice(lista1)
lista2 = ['Pedra', 'Papel', 'Tesoura']
pc2 = lista2[pc1-1]
print('O computador escolheu {}'.format(pc2))
sleep(1)
print('\033[0;33m==+==\033[m'*14)
print('JOooooooo')
sleep(1)
print('KEeeeeeeNnnnn')
sleep(1)
print('POoooooooooo')
sleep(1)
print('\033[0;30;47mJo Ken Poooo\033[m')
print('\033[0;33m==+==\033[m '*14, '\n')
sleep(3)
if jogada == 1 and pc1 == 3:
    print('\033[0;32mVENCEU!!! PARABÉNS!!! Pedra quebra a Tesoura!')
elif jogada == 2 and pc1 == 1:
    print('\033[0;32mVENCEU!!! PARABÉNS!!! Papel engole a Pedra!')
elif jogada == 3 and pc1 == 2:
    print('\033[0;32mVENCEU!!! PARABÉNS!!! Tesoura corta o Papel!')
elif jogada == 1 and pc1 == 2:
    print('\033[0;31mPERDEU!!! LERO LERO!!! Papel engole a Pedra!')
elif jogada == 2 and pc1 == 3:
    print('\033[0;31mPERDEU!!! LERO LERO!!! Tesoura corta o Papel!')
elif jogada == 3 and pc1 == 1:
    print('\033[0;31mPERDEU!!! LERO LERO!!! Pedra quebra a Tesoura!')
else:
    print('\033[0;34mEMPATE!!!! Os dois escolheram o mesmo')
