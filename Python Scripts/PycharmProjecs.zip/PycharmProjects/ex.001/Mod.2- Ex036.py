from time import sleep
print('\033[0;32m==+==\033[m'*10)
print('APROVAÇÃO DE CRÉDITO BANCÁRIO')
print('\033[0;32m==+==\033[m'*10)
sleep(2)
casa = float(input('Insira o valor do imóvel (Em reais):\n'))
renda = float(input('Insira o valor de sua renda mensal (Em reais): \n'))
tempo = int(input('Insira (em meses) quanto tempo quer o financiamento: \n'))
prest = casa / (tempo)
tx = renda * 0.30
print('\033[0;32m==+==\033[m'*10)
print('EM ANÁLISE')
print('\033[0;32m==+==\033[m'*10)
sleep(3)
if tx > prest:
    print('\033[0;30;42m PARABÉNS!!! \033[m Se Crédito foi aprovado!')
    print('Para este tempo, esta prestação ficará R${:.2f}.'.format(prest))
else:
    print('\033[0;30;41m REPROVADO! \033[m Seu credito não foi aceito!')
    print('Aumente o tempo de financiamento ou aumente sua renda.')



