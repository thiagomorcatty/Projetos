#Ex.014 - Temperatura
#Ex.015 - Aluguel de Carros

temp = float(input('QUal a temperatura em ºC? \n'))
print('A temperatura de {} ºC é equivalente a {} F (Farenheint)'.format(temp, ((9*temp)/5)+32))

dias = int(input('Qual a quantidade de dias que foi alugado? \n'))
km = int(input('Quantos km foram utilizados? \n'))
print('Então o total a pagar por {} dias e {} km percorrido: \n R${:.2f}'.format(dias, km, (60*dias)+(0.15*km)))