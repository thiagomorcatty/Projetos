maioridade = homens = mulher20 = 0
while True:
    print('---'*10)
    print('CADASTRE UMA PESSOA')
    print('---'*10)
    idade = int(input('Idade: '))
    if idade >= 18:
        maioridade += 1
    sexo = str(input('Sexo [M/F]: ')).upper().strip()
    if sexo == 'M':
        homens += 1
    if sexo == 'F' and idade <= 20:
        mulher20 += 1
    fim = str(input('Quer cadastrar mais pessoas? [S/N]: ')).upper().strip()
    print('\033[0;31m~~~\033[m'*10)
    if fim == 'N':
        break
print('Fim do Programa!!')
print(f'Total de pessoas com mais de 18 anos: {maioridade}.')
print(f'Ao todo temos {homens} homens cadastrados.')
print(f'E temos {mulher20} mulheres com menos de 20 anos.')