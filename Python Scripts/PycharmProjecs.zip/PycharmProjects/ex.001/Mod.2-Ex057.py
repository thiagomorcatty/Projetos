sexo = 'M'
masc = 0
femi = 0
while sexo != 'S':
    sexo = str(input('Digite M para masculino e F para feminino: ')).strip().upper()
    print('Se, quiser sair, digite S.')
    if sexo == 'M':
        masc += 1
    elif sexo == 'F':
        femi += 1
    else:
        print('Só será aceito as letras F, M e S.')
print('Foram digitados {} Masculinos e {} femininos'.format(masc, femi))
