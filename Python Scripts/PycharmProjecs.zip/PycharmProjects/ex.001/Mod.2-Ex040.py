print('\033[1;36;40m ==+== RESULTADO ESCOLAR ==+== \033[m')
n1 = int(input('Digite a nota 1: \n'))
n2 = int(input('Digite a nota 2: \n'))
print('==+=='*20)
media = (n1 + n2)/2
print('A média do aluno é {}.'.format(media))
if media < 5:
    print('A média está menor que 5, o aluno está \033[1;30;41m REPROVADO!\033[m.')
elif media > 7:
    print('A média e maior que 7, então está \033[1;30;42m APROVADO!\033[m ')
else:
    print('A nota está entre 5 e 7, por isso está de \033[1;30;43m RECUPERAÇÃO!\033[m.')