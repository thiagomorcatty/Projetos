from random import randint
tupla = (randint)
print(f'Os números sorteados foram {tupla[0:4]}')

#print(f'O maior número sorteado foi {maior}')
#print(f'O maior número sorteado foi {menor}')