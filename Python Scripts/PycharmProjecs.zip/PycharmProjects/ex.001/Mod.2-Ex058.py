import random
from time import sleep
lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
num = random.choice(lista)
chute = 0
contachute = 1
while chute != num:
    chute = int(input('Tente advinhar o número escolhido pelo PC: '))
    if chute == num:
        print('Parabéns!!!! Você acertou o número {}!!!'.format(num))
        print('Você acertou em {} chutes'.format(contachute))
    elif chute != num and chute > num:
        contachute += 1
        print('Tente novamente!!, Dica: Ele é menor ')
    else:
        contachute += 1
        print('Tente novamente!!, Dica: Ele é maior')