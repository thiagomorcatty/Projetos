import random
from time import sleep
lista1 =[0, 1, 2, 3, 4, 5]
num1 = random.choice(lista1)
print('-=-'*20)
num2 = int(input('Tente adivinhar qual número de 0 a 5 o computador escolheu: \n'))
print('-=-'*20)
print('PROCESSANDO')
print('-=-'*20)
sleep(2)
if num1 == num2:
    print('Parabéns!!!! Você acertou o número {}!!!'.format(num1))
else:
    print('Que pena!!!! O pc escolheu o número {} e vc escolheu o {}, tente outra vez'.format(num1, num2))
print('-=-'*20)