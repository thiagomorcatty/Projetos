n1 = int(input('Digite o número 1: '))
n2 = int(input('Digite o número 2: '))
n3 = int(input('Digite o número 3: '))
n4 = int(input('Digite o número 4: '))
tupla = n1, n2, n3, n4
print(f'Você digitou os valores {tupla}')
vez = tupla.count(9)
print(f'O valor 9 apareceu {vez} vezes.')
if 3 in tupla:
    pos = tupla.index(3)
    print(f'O valor 3 apareceu na {pos+1}º posição.')
else:
    print(f'O valor 3 não apareceu.')