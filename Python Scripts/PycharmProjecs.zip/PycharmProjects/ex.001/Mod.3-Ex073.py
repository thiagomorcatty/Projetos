times = 'Fla', 'San', 'Pal', 'Gre', 'Ath', 'SP', 'Int', 'Cor', 'For', 'GO', 'BA', 'Vas', 'Atl', 'Flu', 'Bot', 'CE', 'Cru', 'CSA', 'Cha', 'Ava'
print(f'Os 5 primeiros colocados são: {times[0:5]}')
print(f'Os rebaixados foram {times[15:]}')
print(sorted(times))
c = str(input('Escolha o time que quer saber a posição: '))
print(f'A posição do {c} é a {times.index(c)+1}º.')
