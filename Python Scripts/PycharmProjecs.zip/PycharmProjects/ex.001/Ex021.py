from pygame import mixer
from pygame import event
mixer.init()
mixer.music.load('Maroon5-Memories.mp3')
mixer.music.play()
input('Play')
event.wait()
