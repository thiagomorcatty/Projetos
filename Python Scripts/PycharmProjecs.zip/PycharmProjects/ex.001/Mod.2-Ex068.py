print('\033[0;34m===+===\033[m'*5)
print('Vamos Jogar PAR ou IMPAR!!!')
print('\033[0;34m===+===\033[m'*5)
from random import choice
cont = 0
lista1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
while True:
    num = int(input('Digite o número: '))
    parimpar = str(input('Escolar Par [P] ou Ímpar [I]: ')).upper().strip()
    pc1 = choice(lista1)
    if (pc1 + num) % 2 == 0:
        print('\033[0;33m===+===\033[m' * 5)
        print(f'O computador escolheu {pc1} e a soma com o {num} deu {pc1+num} -> PAR.')
        if parimpar == 'P':
            print('\033[0;33m===+===\033[m' * 5)
            print('\033[0;32m VOCÊ GANHOU, PARABENS!!!!\033[m')
            print('\033[0;33m===+===\033[m' * 5)
            cont += 1
        else:
            print('\033[0;32m===+===\033[m' * 5)
            print('\033[0;31mVocê perdeu!!! Que pena, tente denovo\033[m')
            print(f'Você ganhou já {cont} vezes')
            print('\033[0;32m===+===\033[m'*5)
            break
    else:
        print(f'O computador escolheu {pc1} e a soma com o {num} deu {pc1+num} -> ÍMPAR.')
        if parimpar == 'I':
            print('\033[0;33m===+===\033[m' * 5)
            print('\033[0;32m VOCÊ GANHOU, PARABENS!!!!\033[m')
            print('\033[0;33m===+===\033[m' * 5)
            cont += 1
        else:
            print('\033[0;32m===+===\033[m' * 5)
            print('\033[0;31mVocê perdeu!!! Que pena, tente denovo\033[m')
            print(f'Você ganhou já {cont} vezes')
            print('\033[0;32m===+===\033[m' * 5)
            break