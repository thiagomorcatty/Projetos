custo = float(input('Digite o valor do produto (em Reais): \n'))
pag = int(input('Escolha a forma de pagamento: \n 1 - Para dinheiro/cheque. \n 2 - Á vista no Cartão. \n 3 - Dividir 2x no Cartão. \n 4 - Dividir 3x ou mais no cartão. \n Apenas escreva o número: '))
if pag == 1:
    print('O preço de custo é R${:.2f}, mas como foi pago em dinheiro ou cheque a vista, logo custará R${:.2f}'.format(custo, (custo-(custo*0.10))))
elif pag == 2:
    print('O preço de custo é R${:.2f}, mas como foi pago à vista no cartão, tem 5% de desconto, logo custará R${:.2f}'.format(custo, custo-(custo*0.05)))
elif pag == 3:
    print('O preço de custo é R${:.2f}, mas como foi pago em 2x no cartão, não há alteração no preço.'.format(custo))
else:
    print(print('O preço de custo é R${:.2f}, mas como foi pago em 3x ou mais no cartão, terá acréscimo de 20% de juros, logo custará R${:.2f}.'.format(custo, (custo+(custo*0.2)))))