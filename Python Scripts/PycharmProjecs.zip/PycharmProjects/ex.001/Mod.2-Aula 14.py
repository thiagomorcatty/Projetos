for c in range(1,10):
    print(c)
print('fim')
print('\033[0;34m===+===\033[m'*20)
c = 0
while c <10:
    c += 1
    print(c)
print('fim')
print('\033[0;34m===+===\033[m'*20)
c = 1
while c <10:
    print(c)
    c += 1
print('fim')
print('\033[0;34m===+===\033[m'*20)
c1 = 1
while c1 != 0:
    c1 = int(input('Digite um valor: '))
print('Fim')
print('\033[0;34m===+===\033[m'*20)
r = 'S'
while r == 'S':
    r1 = int(input('Digite um valor: '))
    r = str(input('QUer continuar ? [S/N]')).upper()
print('Fim')
print('\033[0;34m===+===\033[m'*20)
par = impar = 0
d = 1
while d != 0:
    d = int(input('Digite um valor: '))
    if d % 2 == 0:
        par +=1
    else:
        impar += 1
print('Você digitou {} números pares e {} númers ímpares'.format(par, impar))