#056 - Analise de dados
print('----- 1ª Pessoa -----')
p1a = input('Nome: ')
p2a = int(input('Idade: '))
p3a = input('Sexo [M/F]: ')
print('----- 2ª Pessoa -----')
p1b = input('Nome: ')
p2b = int(input('Idade: '))
p3b = input('Sexo [M/F]: ')
print('----- 3ª Pessoa -----')
p1c = input('Nome: ')
p2c = int(input('Idade: '))
p3c = input('Sexo [M/F]: ')
print('----- 4ª Pessoa -----')
p1d = input('Nome: ')
p2d = int(input('Idade: '))
p3d = input('Sexo [M/F]: ')
print('----- 5ª Pessoa -----')
p1e = input('Nome: ')
p2e = int(input('Idade: '))
p3e = input('Sexo [M/F]: ')
lista1 = [p1a, p1b, p1c, p1d, p1e]
media = (p2a+p2b+p2c+p2d+p2e)/5
lista3 = [p3a, p3b, p3c, p3d, p3e]
if p3a == 'H':
    if p2a >= (p2b, p2c, p2d, p2e):
        maior = p2a

print('A média de idade do grupo é de {} anos'.format(media))
print('O homem mais velho tem {} anos e se chama {}.'.format())
print()