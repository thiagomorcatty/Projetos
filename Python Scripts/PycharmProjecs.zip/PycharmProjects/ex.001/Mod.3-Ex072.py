num = 'zero', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove', 'dez'
while True:
    numero = int(input('Digite um número de 0 a 10: '))
    if numero in range(0,11):
        print(f'O número escolhido foi o {num[numero]}.')
        print('==='*20)
    elif numero == 999:
        break
    else:
        print('Número inválido, digite um número de 0 a 10: ')
