for oi in range(0, 6):
    print('Oi')

print('\033[0;33m==+==\033[m'*14)
for oi in range (0,6):
    print(oi)

print('\033[0;33m==+==\033[m' * 14)
for oi in range(6, 0, -1):
    print(oi)

print('\033[0;33m==+==\033[m'*14)
for oi in range(7, 2, -2):
    print(oi)

print('\033[0;33m==+==\033[m'*14)
num1 = int(input('Digite um número:\n'))
for cont in range(1, num1):
    print(cont)

print('\033[0;33m==+==\033[m'*14)
num2 = int(input('Digite outro número:\n'))
for cont2 in range(1, num2+1):
    print(cont2)

print('\033[0;33m==+==\033[m'*14)
ini = int(input('Início: '))
fim = int(input('Final: '))
pas = int(input('Passo: '))
for cont3 in range(ini, fim+1, pas):
    print(cont3)

print('\033[0;33m==+==\033[m'*14)
for cont4 in range(0, 4):
    n = int(input('Digite um valor: '))
print(n)

print('\033[0;33m==+==\033[m'*14)
ini2 = 0
for cont5 in range(0, 4):
    n = int(input('Digite um valor: '))
    ini2 += n
print('O somatorio de todos os valores foi {}'.format(ini2))
