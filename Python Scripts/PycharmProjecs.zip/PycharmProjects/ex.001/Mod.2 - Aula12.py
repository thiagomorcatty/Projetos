nome = input('QUal é o seu nome?\n')
if nome == 'Thiago':
    print('Que nome lindo!!!')
elif nome == 'Pedro' or nome == 'Maria' or nome =='Paulo':
    print('Seu nome é popular')
elif nome in 'Ana Claudia Paula Juliana':
    print('Que nome feminino')
else:
    print('Seu nome não é normal')
