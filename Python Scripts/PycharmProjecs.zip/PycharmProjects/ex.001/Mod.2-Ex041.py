from datetime import date
print('\033[1;36;40m ==+== CONFEDERAÇÃO DE NATAÇÃO ==+== \033[m')
nome = input('Digite o nome do atleta: \n')
nasc = int(input('Digite o ano de nascimento: \n'))
idade = (date.today().year) - nasc
print('Olá, {}, você tem {} anos.'.format(nome, idade))
print('A Categoria do atleta: ')
if idade <= 9:
    print('Mirim.')
elif idade > 9 and idade <= 14:
    print('Infantil.')
elif idade > 14 and idade <= 18:
    print('Junior.')
elif idade > 18 and idade <= 20:
    print('Sênior.')
else:
    print('Master.')