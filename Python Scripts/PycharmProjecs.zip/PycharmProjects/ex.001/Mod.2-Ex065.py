num = fim = cont = soma = media = maior = menor = 0
while fim != 'N':
    num = int(input('Digite um número: '))
    fim = str(input('Quer continuar? [S/N]: ')).upper().strip()
    cont += 1
    soma += num
    if cont == 1:
        maior = menor = num
    else:
        if num > maior:
            maior = num
        if num < menor:
            menor = num

media = soma / cont
print(' Você digitou {} números e a media deles foi {}'.format(cont, media))
print('O Maior valor foi {} e o menor valor foi o {}'.format(maior, menor))
