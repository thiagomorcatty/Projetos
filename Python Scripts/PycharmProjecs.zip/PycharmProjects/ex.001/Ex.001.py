#Ex 001
msg = ('Olá, Mundo!!')
print(msg)

#Ex002
nome = input('Digite seu nome: ')
print('Olá,', nome, 'seja bem vindo!!')

#Ex003
nome2 = input('Digite seu nome: ')
print('Olá {}, seja bem vindo!!'.format(nome2))

