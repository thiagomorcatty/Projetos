#Ex.053 - Palindromos

print('\033[0;34m===+===\033[m'*20)
#Ex.054 - Saber se é maior ou menor de idade
from datetime import date
soma = 0
cont = 0
cont2 = 0
for c in range(1,6):
    num = int(input('Digite a idade da pessoa {}: '.format(c)))
    idade = date.today().year - num
    if idade >= 18:
        cont += 1
    else:
        cont2 += 1
print('Tivemos {} pessoas maiores.'.format(cont))
print('Tivemos {} pessoas menores.'.format(cont2))
print('\033[0;34m===+===\033[m'*20)
#055 - Listar maior e menor peso
p1 = float(input('Qual o peso da pessoa 1? '))
p2 = float(input('Qual o peso da pessoa 2? '))
p3 = float(input('Qual o peso da pessoa 3? '))
p4 = float(input('Qual o peso da pessoa 4? '))
p5 = float(input('Qual o peso da pessoa 5? '))
lista1 = [p1, p2, p3, p4, p5]
lista2 = sorted(lista1)
print('O maior peso é {:.0f} kg'.format(lista2[4]))
print('O menor peso é {:.0f} kg'.format(lista2[0]))
print('\033[0;32m===+===\033[m'*10)
maior = 0
menor = 0
for peso1 in range(1,6):
    peso2 = float(input('Peso da pessoa {}: '.format(peso1)))
    if peso1 == 1:
        maior = peso2
        menor = peso2
    else:
        if peso2 > maior:
            maior = peso2
        if peso2 < menor:
            menor = peso2
print('O maior peso é {:.1f} kg'.format(maior))
print('O menor peso é {:.1f} kg'.format(menor))
print('\033[0;34m===+===\033[m'*20)

